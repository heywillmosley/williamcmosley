<div class="fl-page-footer">
	<div class="fl-page-footer-container container">
		<div class="fl-page-footer-row row">
			<?php FLTheme::footer_col1(); ?>
			<?php FLTheme::footer_col2(); ?>
		</div>
	</div>
</div><!-- .fl-page-footer -->