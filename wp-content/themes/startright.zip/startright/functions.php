<?php

// Defines
define( 'FL_CHILD_THEME_DIR', get_stylesheet_directory() );
define( 'FL_CHILD_THEME_URL', get_stylesheet_directory_uri() );

// Classes
require_once 'classes/class-fl-child-theme.php';

// Actions
add_action( 'fl_head', 'FLChildTheme::stylesheet' );

add_action( 'template_redirect', 'wc_custom_redirect_after_purchase' ); 
	function wc_custom_redirect_after_purchase() {
		global $wp;
		
		if ( is_checkout() && ! empty( $wp->query_vars['order-received'] ) ) {
			wp_redirect( '/library/wordpress' );
			exit;
		}
	}
	

add_action('frm_after_create_entry', 'after_entry_created', 30, 2);

function after_entry_created($entry_id, $form_id){

if($form_id == 2){ //change 5 to the ID of your form

$current_user = wp_get_current_user();

//$current_user->remove_role('rolea'); //change rolea to the role you want to remove

$current_user->add_role('ready'); // change roleb to the role you want to add

}

}


//[foobar]
function sub_website_func( $atts ){
    if( is_user_logged_in() ) {
        $url = get_the_author_meta( 'url' );
        
        if( ! empty( $url ) ) {
            echo "<a href='" . $url . "' target='_blank'><i class='fa fa-home' aria-hidden='true'></i></a>";
        }
    }
}
add_shortcode( 'sub_website', 'sub_website_func' );