<div class="frm-show-click" style="margin:7px 0 5px;">
<?php echo esc_attr( $opt_label ) ?>:&nbsp;<?php
	require( FrmAppHelper::plugin_path() .'/pro/classes/views/lookup-fields/back-end/get-options-from.php' );
?></div>
