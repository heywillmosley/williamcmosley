<?php
/**
 * Plugin Name: Beaver Themer
 * Plugin URI: https://www.wpbeaverbuilder.com/?utm_medium=bb-theme-builder&utm_source=plugins-admin-page&utm_campaign=plugins-admin-uri
 * Description: Easily build theme layouts for your archives, posts, 404 pages and more!
 * Version: 1.0
 * Author: The Beaver Builder Team
 * Author URI: https://www.wpbeaverbuilder.com/?utm_medium=bb-theme-builder&utm_source=plugins-admin-page&utm_campaign=plugins-admin-author
 * Copyright: (c) 2016 Beaver Builder
 * License: GNU General Public License v2.0
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: fl-theme-builder
 */

require_once 'classes/class-fl-theme-builder-loader.php';
