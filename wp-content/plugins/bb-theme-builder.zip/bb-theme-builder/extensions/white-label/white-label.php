<?php

// Defines
define( 'FL_THEME_BUILDER_WHITE_LABEL_DIR', FL_THEME_BUILDER_DIR . 'extensions/white-label/' );
define( 'FL_THEME_BUILDER_WHITE_LABEL_URL', FL_THEME_BUILDER_URL . 'extensions/white-label/' );

// Classes
require_once FL_THEME_BUILDER_WHITE_LABEL_DIR . 'classes/class-fl-theme-builder-white-label.php';
