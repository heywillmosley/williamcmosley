<?php

echo FLPageDataWooCommerce::get_add_to_cart_button();
