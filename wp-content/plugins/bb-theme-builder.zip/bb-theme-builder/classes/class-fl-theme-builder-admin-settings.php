<?php

/**
 * Admin settings for the theme builder.
 *
 * @since 1.0
 */
final class FLThemeBuilderAdminSettings {

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0
	 * @return void
	 */
	static public function init() {}
}

FLThemeBuilderAdminSettings::init();
