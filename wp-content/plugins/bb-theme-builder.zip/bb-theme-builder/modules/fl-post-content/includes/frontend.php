<?php

echo FLPageDataPost::get_content();
