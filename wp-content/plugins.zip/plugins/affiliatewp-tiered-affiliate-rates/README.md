Tiered Affiliate Rates
======================

This add-on for AffiliateWP allows you to create tiered affiliate rates, meaning that you can reward your affiliates with higher commission rates as they earn more or refer for customers.