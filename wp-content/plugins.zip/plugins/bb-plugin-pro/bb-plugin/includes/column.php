<div<?php echo FLBuilder::render_column_attributes( $col ); ?>>
	<div class="fl-col-content fl-node-content">
	<?php FLBuilder::render_modules( $col ); ?>
	</div>
</div>