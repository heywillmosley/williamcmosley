<script type="text/javascript">

if(typeof jQuery == 'undefined' || typeof jQuery.fn.on == 'undefined') {
	document.write('<script src="<?php echo FL_BUILDER_URL ?>js/jquery.js"><\/script>');
	document.write('<script src="<?php echo FL_BUILDER_URL ?>js/jquery.migrate.min.js"><\/script>');
}

</script>