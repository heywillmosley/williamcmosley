<div<?php FLBuilder::render_module_attributes( $module ); ?>>
	<div class="fl-module-content fl-node-content">
		<?php include $module->dir . 'includes/frontend.php';  ?>
	</div>
</div>